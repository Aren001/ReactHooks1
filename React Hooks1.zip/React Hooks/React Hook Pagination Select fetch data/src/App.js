import React from 'react';
import Header from './components/common/Header';
import List from './components/List/List';


const App = (props) => {
  
  return (
    <div >
        <Header />
       <List />
           
      
    </div>
  );
}

export default App;
