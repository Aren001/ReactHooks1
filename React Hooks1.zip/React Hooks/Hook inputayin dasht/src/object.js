const obj=[
    {
        name:'Ara',
        age:18,
        first:'Bari'
    },
    {
        name:'Babo',
        age:19,
        first:'Bari'
    },
    {
        name:'Gago',
        age:20,
        first:'Bari'
    },
    {
        name:'Nana',
        age:22,
        first:'Bari'
    },
    {
        name:'Araik',
        age:22,
        first:'Bari'
    }
]

export default obj;