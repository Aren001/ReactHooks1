import React, { useState, useEffect } from 'react';
import obj from './object';

const App = (props) => {
  

    console.log(props)
    const [value , setValue]=useState('');
    const [obj1 , setobj1]=useState(obj);
    
    
const foo = (e) => {
    setValue(e.target.value);
    console.log(e.target.value)
   
}

// useEffect(() => {
//     setobj1(obj);
// })

const sbmitt= (e) => {
    e.preventDefault();
    if(value==''){
        alert('enter name');
    }
}

    

    return (
    <div>
        <form onSubmit={sbmitt}> 
        <input
        type="text"
        value={value}
        onChange={foo}
    />
    </form>
   
        {
            obj1.map((e,index) => {
                if((e.name).toLocaleLowerCase()==value){
                    return (
                        <div key={index}>
                            <h1>{e.name}</h1>
                            <h1>{e.age}</h1>
                            <h1>{e.first}</h1>
                        </div>
                    )
                }
            })
        }



    </div>
    )
}
export default App;
