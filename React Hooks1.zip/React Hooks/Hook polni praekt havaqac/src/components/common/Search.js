import React, {useState} from 'react';
import { withRouter } from 'react-router-dom';
import { API_URL } from '../../config';
import Loading from '../common/Loading';
import './Search.css';
const Search = (props) => {



    
    const [loading, setLoading] = useState('');  
    const [searchQuery, setSearchQuery] = useState('');  //input
    const [searchResults, setSearchResults] = useState([]);  // listenq sarqum lcum zangvaci mej



    const handleChange =  (e) => {



        // console.log(e);
        const searchQuery = e.target.value;
        setSearchQuery(searchQuery);
        setLoading(true);
        // console.log(searchResults);
        
        
            fetch(`${API_URL}/autocomplete?searchQuery=${searchQuery}`) ///es ameny beck-end-i mej sarqaca
            .then(resp => resp.json())
            .then(data => {
                setLoading(false);
                setSearchResults(data);
            })
            .catch(err => {
                console.log('ERPRR',err)
            })
        
    }



   
    const handleRedirect = (Id) => {
        setSearchQuery('');
        setSearchResults([]);
        console.log(Id);
        props.history.push(`/currency/${Id}`)   //gna es id-ov click-i jamanak App.js  nshaca vor gna Detail component

    }


    //ardyunqy sharuma list
    const renderSearchResults = () => {
        if(!searchQuery) {
            return ''
        }
        if(searchResults.length > 0) {
            return (
                <div className="Search-result-container">
                    {
                       searchResults.map(result => (
                           <div
                            key={result.id}
                            className="Search-result"
                            onClick={() => handleRedirect(result.id)}
                           >
                                {result.name} ({result.symbol})
                            </div>
                       )) 
                    }
                </div>
            )
        }
           
       return (
           <div className="Search-result-container">
                <div className="Search-no-result">
                    No results found.
                </div>
           </div>
       )
      
    }
    return (
        <div className="Search">
            <div>
                <span className="Search-icon" />
                <input 
                    type="text"
                    placeholder="Currency name"
                    className="Search-input"
                    onChange={handleChange}
                    value={searchQuery}
                />
                {
                    loading && searchQuery &&
                    (
                        <div className="Search-loading">
                            <Loading 
                                width="15px"
                                height="15px"
                            />
                        </div>
                    )
                }
            </div>
            {renderSearchResults()}
        </div>
    )
}
export default withRouter(Search);