import React from 'react';


const Select = ({perPage , handleChangeSelect}) => {



    return <div style={{marginLeft:'30px' , display:'flex'}} >
        <h4>📜</h4>
        <select vlaue={perPage}   onChange={handleChangeSelect}     style={{backgroundColor:'#12263D' , color:'white' , border:'none' }} >
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="50">50</option>
        </select>
    </div>
}

export default Select;
